# Barbería + Módulo MongoDB TypeScript

Proyecto Node.js con un módulo de conexión a MongoDB escrito en TypeScript y utilidades para definir esquemas (validadores) e importar datos de ejemplo de una barbería.

## Requisitos
- Node.js 18+ y npm
- Una instancia de MongoDB (Atlas o local)

## Instalación
```bash
npm install
npm run build
```

## Variables de entorno
- `MONGODB_URI`: URI de conexión a MongoDB. No colocar credenciales en el repositorio.
- `MONGODB_DEFAULT_DB`: nombre de la base de datos por defecto (ej. `barberia`).
- Opcionales del cliente:
  - `MONGODB_MODE`: `persistent` | `temporary` (por defecto `persistent`).
  - `MONGODB_APP_NAME`: nombre de la aplicación.
  - `MONGODB_STRICT`: `true`/`false` (por defecto `true`).
  - `MONGODB_DEPRECATION_ERRORS`: `true`/`false` (por defecto `true`).
  - `MONGODB_SERVER_API_VERSION`: `1` | `v1`.
  - `MONGODB_CLIENT_OPTIONS`: JSON de configuración extra del `MongoClient`.
- `API_NAME`, `API_ENV`: metadatos opcionales.

Puedes usar un archivo `.env` (no incluido) o establecer las variables en tu terminal.

## Módulo de Conexión (TypeScript)
Clase `DatabaseConnection` que encapsula la conexión a MongoDB con métodos:
- `connect()`
- `ping()`
- `close()`
- `getDatabase(name?)`

Ubicaciones:
- `src/db/connection.ts`
  - Clase: `src/db/connection.ts:71`
  - `connect`: `src/db/connection.ts:81`
  - `ping`: `src/db/connection.ts:110`
  - `close`: `src/db/connection.ts:123`
  - `getDatabase`: `src/db/connection.ts:138`
  - `fromEnv`: `src/db/connection.ts:146`

Exportaciones de tipos y clases: `src/index.ts`

### Ejemplo de uso
```ts
import { DatabaseConnection } from './dist/index.js'

async function main() {
  const conn = DatabaseConnection.fromEnv()
  const res = await conn.connect()
  if (!res.success) throw res.error

  const ping = await conn.ping()
  if (!ping.success) throw ping.error

  const db = conn.getDatabase(process.env.MONGODB_DEFAULT_DB || 'admin')
  // ... usa db.collection(...)

  await conn.close()
}
```

## Esquemas y Datos de Barbería
Los archivos JSON de ejemplo están en `c:\Users\DUOC\Documents\trae_projects\db\Barberia`.

### Tipos TypeScript
`src/barberia/types.ts` define interfaces para:
- `Barbero`, `Cliente`, `Local`, `Producto`, `Servicio`
- `Reserva` (con servicios anidados)
- `Venta` (con servicios y productos anidados)

### Aplicar Validadores (JSON Schema)
`src/barberia/setup-schema.ts` crea/actualiza validadores en MongoDB y define índices (incluyendo `id` único por colección).

Windows (PowerShell):
```powershell
$env:MONGODB_URI="mongodb+srv://<usuario>:<password>@<cluster>/?appName=<App>"
$env:MONGODB_DEFAULT_DB="barberia"
npx ts-node src/barberia/setup-schema.ts
```

### Importar los JSON a la Base de Datos
`src/barberia/seed-data.ts` lee los JSON y los inserta en MongoDB, convirtiendo:
- Números a `Int32` cuando el validador requiere `int`
- `fecha` a `Date`

Windows (PowerShell):
```powershell
$env:MONGODB_URI="mongodb+srv://<usuario>:<password>@<cluster>/?appName=<App>"
$env:MONGODB_DEFAULT_DB="barberia"
$env:BARBERIA_DATA_DIR="c:\Users\DUOC\Documents\trae_projects\db\Barberia"
npx ts-node src/barberia/seed-data.ts
```

## Estructura del Proyecto
- `src/db/connection.ts`: Módulo de conexión tipado.
- `src/index.ts`: Exporta clases y tipos.
- `src/barberia/types.ts`: Interfaces de dominio.
- `src/barberia/setup-schema.ts`: Aplicación de validadores e índices.
- `src/barberia/seed-data.ts`: Importación de datos JSON.

## Solución de Problemas
- `Missing required environment variable: MONGODB_URI`: establece `MONGODB_URI` en tu entorno o `.env`.
- `Document failed validation (code 121)`: revisa que los tipos coincidan con el validador. El importador convierte enteros (`Int32`) y fechas, pero si cambias los validadores, ajusta el importador.
- Errores de red/credenciales: valida tu URI y accesos en Atlas o instancia local.

## Seguridad
- No compartas credenciales en el repositorio.
- Usa variables de entorno o gestores de secretos.

## Scripts útiles
En `package.json`:
- `build`: compila TypeScript a `dist/`.
- `typecheck`: valida tipos sin emitir.
- `dev`: ejecuta `src/index.ts` con `ts-node`.

Scripts disponibles:
- `menu`: menú interactivo CRUD por consola
  - `npm run menu`
- `cli`: cliente CLI para CRUD de clientes
  - `npm run cli -- create --id=123`
  - `npm run cli -- read --id=123`
  - `npm run cli -- update --id=123`
  - `npm run cli -- delete --id=123`
- `schema`: aplica validadores e índices
  - `npm run schema`
- `seed`: importa datos JSON
  - `npm run seed`

Todos los scripts requieren establecer variables de entorno antes de ejecutarlos.

## Uso del CRUD
- Consola interactiva:
  ```powershell
  $env:MONGODB_URI="mongodb+srv://<usuario>:<password>@<cluster>/?appName=<App>"
  $env:MONGODB_DEFAULT_DB="barberia"
  npm run menu
  ```
- CLI por comandos:
  ```powershell
  $env:MONGODB_URI="mongodb+srv://<usuario>:<password>@<cluster>/?appName=<App>"
  $env:MONGODB_DEFAULT_DB="barberia"
  npm run cli -- create --id=3000001
  npm run cli -- read --id=3000001
  npm run cli -- update --id=3000001
  npm run cli -- delete --id=3000001
  ```

## Arquitectura
- Ver `ARCHITECTURE.md` para una explicación de alto nivel de la estructura y responsabilidades de cada módulo.

## Contribución
- Haz fork y crea ramas por feature.
- Ejecuta `npm run typecheck` antes de abrir PR.
- Sigue las convenciones de nombres y tipos de este proyecto.

## Licencia
- ISC. Puedes usar y modificar este código respetando la licencia.