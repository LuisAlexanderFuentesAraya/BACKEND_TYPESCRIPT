import { config as loadEnv } from 'dotenv'
import {
  MongoClient,
  MongoClientOptions,
  ServerApiVersion,
  Db,
  InsertOneResult,
  UpdateResult,
  DeleteResult,
  Collection,
} from 'mongodb'

export type ConnectionMode = 'persistent' | 'temporary'

export interface OperationResult<T> { success: boolean; data?: T; error?: MongoErrorLike; details?: Record<string, unknown> }
export type MongoErrorLike = Error & { code?: string | number; codeName?: string }

export interface ConnectionOptions {
  uri: string
  appName?: string
  defaultDb?: string
  mode?: ConnectionMode
  serverApi?: { version: ServerApiVersion; strict?: boolean; deprecationErrors?: boolean }
  clientOptions?: Omit<MongoClientOptions, 'serverApi'>
}

export interface ApiConfigParams { name?: string; env?: string }
export interface MongoConfigParams { connection: ConnectionOptions; api?: ApiConfigParams }

export class ConnectionError extends Error { readonly code = 'CONNECTION_ERROR'; constructor(message: string, public readonly cause?: unknown) { super(message); this.name = 'ConnectionError' } }
export class PingError extends Error { readonly code = 'PING_ERROR'; constructor(message: string, public readonly cause?: unknown) { super(message); this.name = 'PingError' } }
export class CloseError extends Error { readonly code = 'CLOSE_ERROR'; constructor(message: string, public readonly cause?: unknown) { super(message); this.name = 'CloseError' } }

export class DatabaseConnection {
  private client: MongoClient | null = null
  private readonly opts: ConnectionOptions
  private readonly api: ApiConfigParams | undefined

  constructor(params: MongoConfigParams) { this.opts = params.connection; this.api = params.api }

  async connect(): Promise<OperationResult<MongoClient>> {
    try {
      if (this.client) return { success: true, data: this.client }
      const baseOptions: MongoClientOptions = {
        serverApi: this.opts.serverApi ?? { version: ServerApiVersion.v1, strict: true, deprecationErrors: true },
        ...(this.opts.clientOptions ?? {}),
      }
      if (this.opts.appName) baseOptions.appName = this.opts.appName
      const client = new MongoClient(this.opts.uri, baseOptions)
      await client.connect()
      this.client = client
      return { success: true, data: client }
    } catch (err) {
      return { success: false, error: new ConnectionError('Failed to connect to MongoDB', err) }
    }
  }

  async ping(dbName = 'admin'): Promise<OperationResult<{ ok: number }>> {
    try {
      const client = await this.ensureClient()
      const result = await client.db(dbName).command({ ping: 1 })
      return { success: true, data: result as { ok: number } }
    } catch (err) {
      return { success: false, error: new PingError('Ping command failed', err) }
    }
  }

  async close(force = false): Promise<OperationResult<void>> {
    try { if (this.client) { await this.client.close(force); this.client = null } return { success: true } }
    catch (err) { return { success: false, error: new CloseError('Failed to close MongoDB client', err) } }
  }

  getDatabase(dbName?: string): Db {
    if (!this.client) throw new ConnectionError('MongoDB client is not connected')
    const name = dbName ?? this.opts.defaultDb ?? 'admin'
    return this.client.db(name)
  }

  static fromEnv(): DatabaseConnection {
    loadEnv()
    const appName = process.env.MONGODB_APP_NAME
    const uri = (process.env.MONGODB_URI && process.env.MONGODB_URI.trim().length > 0)
      ? process.env.MONGODB_URI
      : `mongodb://127.0.0.1:27017/?appName=${appName || 'BarberiaApp'}`
    const mode = process.env.MONGODB_MODE === 'temporary' ? 'temporary' : 'persistent'
    const defaultDb = process.env.MONGODB_DEFAULT_DB
    const strict = envBoolean('MONGODB_STRICT', true)
    const deprecationErrors = envBoolean('MONGODB_DEPRECATION_ERRORS', true)
    const version = parseServerApiVersion(process.env.MONGODB_SERVER_API_VERSION)
    const clientOptions = parseJson(process.env.MONGODB_CLIENT_OPTIONS)
    const apiName = process.env.API_NAME
    const apiEnv = process.env.API_ENV
    const api: ApiConfigParams | undefined = apiName || apiEnv ? { ...(apiName ? { name: apiName } : {}), ...(apiEnv ? { env: apiEnv } : {}) } : undefined
    const connection: ConnectionOptions = {
      uri,
      ...(appName ? { appName } : {}),
      ...(defaultDb ? { defaultDb } : {}),
      ...(mode ? { mode } : {}),
      serverApi: { version, strict, deprecationErrors },
      clientOptions: clientOptions ?? {},
    }
    return api ? new DatabaseConnection({ connection, api }) : new DatabaseConnection({ connection })
  }

  async ensureClient(): Promise<MongoClient> {
    if (this.client) return this.client
    const res = await this.connect()
    if (!res.success || !res.data) throw res.error ?? new ConnectionError('Unknown connection error')
    return res.data
  }
}

function mustGet(name: string): string { const v = process.env[name]; if (!v || v.trim().length === 0) { throw new ConnectionError(`Missing required environment variable: ${name}`) } return v }
function envBoolean(name: string, defaultValue: boolean): boolean { const v = process.env[name]; if (v === undefined) return defaultValue; return /^(1|true|yes|on)$/i.test(v) }
function parseJson<T = Record<string, unknown>>(raw?: string): T | undefined { if (!raw) return undefined; try { return JSON.parse(raw) as T } catch (e) { throw new ConnectionError('Invalid JSON in environment variable MONGODB_CLIENT_OPTIONS', e) } }
function parseServerApiVersion(v?: string): ServerApiVersion { if (!v) return ServerApiVersion.v1; const lower = v.toLowerCase(); if (lower === '1' || lower === 'v1') return ServerApiVersion.v1; return ServerApiVersion.v1 }

export type { MongoClientOptions, ServerApiVersion, Db, Collection, InsertOneResult, UpdateResult, DeleteResult }