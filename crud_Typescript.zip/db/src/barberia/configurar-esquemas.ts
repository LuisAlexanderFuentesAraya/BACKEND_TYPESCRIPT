import { DatabaseConnection } from '../index'

const vBarberos = {
  $jsonSchema: {
    bsonType: 'object',
    required: ['id', 'nombre', 'horario', 'id_local'],
    properties: { _id: { bsonType: 'objectId' }, id: { bsonType: 'int' }, nombre: { bsonType: 'string', maxLength: 200 }, horario: { bsonType: 'string', pattern: '^\\d{2}:\\d{2}-\\d{2}:\\d{2}$' }, id_local: { bsonType: 'int' } },
    additionalProperties: false
  }
}

const vClientes = {
  $jsonSchema: {
    bsonType: 'object',
    required: ['id', 'nombre', 'telefono'],
    properties: { _id: { bsonType: 'objectId' }, id: { bsonType: 'int' }, nombre: { bsonType: 'string', maxLength: 200 }, telefono: { bsonType: 'string', maxLength: 30 } },
    additionalProperties: false
  }
}

const vLocales = {
  $jsonSchema: {
    bsonType: 'object',
    required: ['id', 'nombre', 'direccion'],
    properties: { _id: { bsonType: 'objectId' }, id: { bsonType: 'int' }, nombre: { bsonType: 'string', maxLength: 200 }, direccion: { bsonType: 'string', maxLength: 300 } },
    additionalProperties: false
  }
}

const vProductos = {
  $jsonSchema: {
    bsonType: 'object',
    required: ['id', 'nombre', 'tipo', 'estado', 'stock'],
    properties: { _id: { bsonType: 'objectId' }, id: { bsonType: 'int' }, nombre: { bsonType: 'string', maxLength: 200 }, tipo: { bsonType: 'string', maxLength: 100 }, estado: { bsonType: 'string', maxLength: 50 }, stock: { bsonType: 'int', minimum: 0 } },
    additionalProperties: false
  }
}

const vServicios = {
  $jsonSchema: {
    bsonType: 'object',
    required: ['id', 'nombre', 'precio', 'duracion'],
    properties: { _id: { bsonType: 'objectId' }, id: { bsonType: 'int' }, nombre: { bsonType: 'string', maxLength: 200 }, precio: { bsonType: 'int', minimum: 0 }, duracion: { bsonType: 'string', pattern: '^\\d+\\s+minutos?$' } },
    additionalProperties: false
  }
}

const vReservas = {
  $jsonSchema: {
    bsonType: 'object',
    required: ['id', 'fecha', 'hora', 'barbero', 'cliente', 'servicios'],
    properties: {
      _id: { bsonType: 'objectId' },
      id: { bsonType: 'int' },
      fecha: { bsonType: 'date' },
      hora: { bsonType: 'string', pattern: '^\\d{2}:\\d{2}$' },
      barbero: { bsonType: 'object', required: ['id', 'nombre'], properties: { id: { bsonType: 'int' }, nombre: { bsonType: 'string' } }, additionalProperties: false },
      cliente: { bsonType: 'object', required: ['id', 'nombre'], properties: { id: { bsonType: 'int' }, nombre: { bsonType: 'string' } }, additionalProperties: false },
      servicios: { bsonType: 'array', items: { bsonType: 'object', required: ['id_servicio', 'nombre', 'precio', 'duracion'], properties: { id_servicio: { bsonType: 'int' }, nombre: { bsonType: 'string' }, precio: { bsonType: 'int', minimum: 0 }, duracion: { bsonType: 'string', pattern: '^\\d+\\s+minutos?$' } }, additionalProperties: false } }
    },
    additionalProperties: false
  }
}

const vVentas = {
  $jsonSchema: {
    bsonType: 'object',
    required: ['id', 'fecha', 'monto_total', 'barbero', 'cliente', 'servicios', 'productos'],
    properties: {
      _id: { bsonType: 'objectId' },
      id: { bsonType: 'int' },
      fecha: { bsonType: 'date' },
      monto_total: { bsonType: 'int', minimum: 0 },
      barbero: { bsonType: 'object', required: ['id', 'nombre'], properties: { id: { bsonType: 'int' }, nombre: { bsonType: 'string' } }, additionalProperties: false },
      cliente: { bsonType: 'object', required: ['id', 'nombre'], properties: { id: { bsonType: 'int' }, nombre: { bsonType: 'string' } }, additionalProperties: false },
      servicios: { bsonType: 'array', items: { bsonType: 'object', required: ['id_servicio', 'nombre', 'cantidad', 'precio_unitario', 'subtotal'], properties: { id_servicio: { bsonType: 'int' }, nombre: { bsonType: 'string' }, cantidad: { bsonType: 'int', minimum: 1 }, precio_unitario: { bsonType: 'int', minimum: 0 }, subtotal: { bsonType: 'int', minimum: 0 } }, additionalProperties: false } },
      productos: { bsonType: 'array', items: { bsonType: 'object', required: ['id_producto', 'nombre', 'cantidad', 'subtotal'], properties: { id_producto: { bsonType: 'int' }, nombre: { bsonType: 'string' }, cantidad: { bsonType: 'int', minimum: 1 }, subtotal: { bsonType: 'int', minimum: 0 } }, additionalProperties: false } }
    },
    additionalProperties: false
  }
}

async function applyValidator(db: any, name: string, validator: any) {
  const exists = await db.listCollections({ name }).toArray()
  if (exists.length === 0) {
    await db.createCollection(name, { validator, validationLevel: 'strict', validationAction: 'error' })
  } else {
    await db.command({ collMod: name, validator, validationLevel: 'strict', validationAction: 'error' })
  }
}

async function main() {
  const conn = DatabaseConnection.fromEnv()
  const res = await conn.connect()
  if (!res.success) throw res.error
  const db = conn.getDatabase(process.env.MONGODB_DEFAULT_DB || 'admin')

  await applyValidator(db, 'barberos', vBarberos)
  await applyValidator(db, 'clientes', vClientes)
  await applyValidator(db, 'locales', vLocales)
  await applyValidator(db, 'productos', vProductos)
  await applyValidator(db, 'servicios', vServicios)
  await applyValidator(db, 'reservas', vReservas)
  await applyValidator(db, 'ventas', vVentas)

  await db.collection('barberos').createIndex({ id: 1 }, { unique: true })
  await db.collection('clientes').createIndex({ id: 1 }, { unique: true })
  await db.collection('locales').createIndex({ id: 1 }, { unique: true })
  await db.collection('productos').createIndex({ id: 1 }, { unique: true })
  await db.collection('servicios').createIndex({ id: 1 }, { unique: true })
  await db.collection('reservas').createIndex({ id: 1 }, { unique: true })
  await db.collection('ventas').createIndex({ id: 1 }, { unique: true })

  await db.collection('reservas').createIndex({ 'barbero.id': 1 })
  await db.collection('reservas').createIndex({ 'cliente.id': 1 })
  await db.collection('reservas').createIndex({ fecha: 1 })
  await db.collection('ventas').createIndex({ 'barbero.id': 1 })
  await db.collection('ventas').createIndex({ 'cliente.id': 1 })
  await db.collection('ventas').createIndex({ fecha: 1 })

  await conn.close()
}

main().catch(err => { console.error(err); process.exit(1) })