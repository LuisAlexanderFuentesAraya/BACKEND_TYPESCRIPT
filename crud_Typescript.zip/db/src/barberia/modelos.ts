import { ObjectId } from 'mongodb'
export type Id = number
export interface Barbero { _id?: ObjectId; id: Id; nombre: string; horario: string; id_local: Id }
export interface Cliente { _id?: ObjectId; id: Id; nombre: string; telefono: string }
export interface Local { _id?: ObjectId; id: Id; nombre: string; direccion: string }
export interface Producto { _id?: ObjectId; id: Id; nombre: string; tipo: string; estado: string; stock: number }
export interface Servicio { _id?: ObjectId; id: Id; nombre: string; precio: number; duracion: string }
export interface ReservaServicio { id_servicio: Id; nombre: string; precio: number; duracion: string }
export interface Reserva { _id?: ObjectId; id: Id; fecha: Date; hora: string; barbero: { id: Id; nombre: string }; cliente: { id: Id; nombre: string }; servicios: ReservaServicio[] }
export interface VentaServicio { id_servicio: Id; nombre: string; cantidad: number; precio_unitario: number; subtotal: number }
export interface VentaProducto { id_producto: Id; nombre: string; cantidad: number; subtotal: number }
export interface Venta { _id?: ObjectId; id: Id; fecha: Date; monto_total: number; barbero: { id: Id; nombre: string }; cliente: { id: Id; nombre: string }; servicios: VentaServicio[]; productos: VentaProducto[] }