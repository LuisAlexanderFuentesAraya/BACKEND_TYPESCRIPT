import readline from 'readline'
import { BarberiaCRUD } from '../index'

/** Crea una interfaz readline para una pregunta */
function rl() { return readline.createInterface({ input: process.stdin, output: process.stdout }) }
/** Pregunta en consola y retorna la respuesta recortada */
function ask(q: string): Promise<string> { const i = rl(); return new Promise(res => i.question(q, ans => { i.close(); res(ans.trim()) })) }
/** Parsea entero opcional */
async function askInt(q: string): Promise<number | undefined> { const s = await ask(q); const n = parseInt(s, 10); return Number.isInteger(n) ? n : undefined }
/** Solicita entero obligatorio con rango */
async function askIntStrict(q: string, min?: number, max?: number): Promise<number> { while (true) { const n = await askInt(q); if (n !== undefined && (min === undefined || n >= min) && (max === undefined || n <= max)) return n; console.log('valor inválido') } }
/** Solicita entero opcional con reintento */
async function askIntOptional(q: string): Promise<number | undefined> { const s = await ask(q); if (!s) return undefined; const n = parseInt(s, 10); if (!Number.isInteger(n)) { console.log('valor inválido'); return askIntOptional(q) } return n }
/** Solicita string no vacío */
async function askNonEmpty(q: string): Promise<string> { while (true) { const s = await ask(q); if (s) return s; console.log('valor requerido') } }
/** Valida hora HH:MM */
function isTime(s: string): boolean { return /^([01]\d|2[0-3]):[0-5]\d$/.test(s) }
/** Valida horario HH:MM-HH:MM */
function isTimeRange(s: string): boolean { return /^([01]\d|2[0-3]):[0-5]\d-([01]\d|2[0-3]):[0-5]\d$/.test(s) }
/** Valida fecha ISO YYYY-MM-DD */
function isDateISO(s: string): boolean { if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false; const d = new Date(s); return !isNaN(d.getTime()) }
/** Solicita hora válida */
async function askTime(q: string): Promise<string> { while (true) { const s = await ask(q); if (isTime(s)) return s; console.log('hora inválida') } }
/** Solicita hora opcional válida */
async function askTimeOptional(q: string): Promise<string | undefined> { const s = await ask(q); if (!s) return undefined; if (!isTime(s)) { console.log('hora inválida'); return askTimeOptional(q) } return s }
/** Solicita rango de horario válido */
async function askTimeRange(q: string): Promise<string> { while (true) { const s = await ask(q); if (isTimeRange(s)) return s; console.log('horario inválido') } }
/** Solicita fecha ISO válida y retorna Date */
async function askDateISO(q: string): Promise<Date> { while (true) { const s = await ask(q); if (isDateISO(s)) return new Date(s); console.log('fecha inválida') } }
/** Solicita teléfono en formato aceptado */
async function askPhone(q: string): Promise<string> { while (true) { const s = await ask(q); if (/^[+0-9\s-]{7,20}$/.test(s)) return s; console.log('telefono inválido') } }
/** Solicita string opcional con validación */
async function askOptionalString(q: string, validate?: (s: string) => boolean): Promise<string | undefined> { const s = await ask(q); if (!s) return undefined; if (validate && !validate(s)) { console.log('valor inválido'); return askOptionalString(q, validate) } return s }

async function menuClientes(crud: BarberiaCRUD) {
  while (true) {
    console.log('\nClientes: 1) Crear 2) Leer 3) Actualizar 4) Eliminar 0) Atrás')
    const op = await ask('Opción: ')
    if (op === '0') break
    if (op === '1') { const id = await askIntStrict('id: ', 1); const nombre = await askNonEmpty('nombre: '); const telefono = await askPhone('telefono: '); const r = await crud.createCliente({ id, nombre, telefono }); console.log('creado', r.insertedId); continue }
    if (op === '2') { const id = await askIntStrict('id: ', 1); console.log('doc', await crud.getClienteById(id)); continue }
    if (op === '3') { const id = await askIntStrict('id: ', 1); const telefono = await askPhone('nuevo telefono: '); const u = await crud.updateClienteById(id, { telefono }); console.log('updated', u.modifiedCount); console.log('doc', await crud.getClienteById(id)); continue }
    if (op === '4') { const id = await askIntStrict('id: ', 1); const del = await crud.deleteClienteById(id); console.log('deleted', del.deletedCount); console.log('doc', await crud.getClienteById(id)); continue }
    console.log('Opción inválida')
  }
}

async function menuBarberos(crud: BarberiaCRUD) {
  while (true) {
    console.log('\nBarberos: 1) Crear 2) Leer 3) Actualizar 4) Eliminar 0) Atrás')
    const op = await ask('Opción: ')
    if (op === '0') break
    if (op === '1') { const id = await askIntStrict('id: ', 1); const id_local = await askIntStrict('id_local: ', 1); const nombre = await askNonEmpty('nombre: '); const horario = await askTimeRange('horario (HH:MM-HH:MM): '); const r = await crud.createBarbero({ id, id_local, nombre, horario }); console.log('creado', r.insertedId); continue }
    if (op === '2') { const id = await askIntStrict('id: ', 1); console.log('doc', await crud.getBarberoById(id)); continue }
    if (op === '3') { const id = await askIntStrict('id: ', 1); const nombre = await askOptionalString('nombre (enter para mantener): '); const horario = await askOptionalString('horario (enter para mantener): ', isTimeRange); const id_local = await askIntOptional('id_local (enter para mantener): '); const updates: Partial<any> = {}; if (nombre) updates.nombre = nombre; if (horario) updates.horario = horario; if (id_local !== undefined) updates.id_local = id_local; const u = await crud.updateBarberoById(id, updates as any); console.log('updated', u.modifiedCount); console.log('doc', await crud.getBarberoById(id)); continue }
    if (op === '4') { const id = await askIntStrict('id: ', 1); const del = await crud.deleteBarberoById(id); console.log('deleted', del.deletedCount); console.log('doc', await crud.getBarberoById(id)); continue }
    console.log('Opción inválida')
  }
}

async function menuLocales(crud: BarberiaCRUD) {
  while (true) {
    console.log('\nLocales: 1) Crear 2) Leer 3) Actualizar 4) Eliminar 0) Atrás')
    const op = await ask('Opción: ')
    if (op === '0') break
    if (op === '1') { const id = await askIntStrict('id: ', 1); const nombre = await askNonEmpty('nombre: '); const direccion = await askNonEmpty('direccion: '); const r = await crud.createLocal({ id, nombre, direccion }); console.log('creado', r.insertedId); continue }
    if (op === '2') { const id = await askIntStrict('id: ', 1); console.log('doc', await crud.getLocalById(id)); continue }
    if (op === '3') { const id = await askIntStrict('id: ', 1); const nombre = await askOptionalString('nombre (enter para mantener): '); const direccion = await askOptionalString('direccion (enter para mantener): '); const updates: Partial<any> = {}; if (nombre) updates.nombre = nombre; if (direccion) updates.direccion = direccion; const u = await crud.updateLocalById(id, updates as any); console.log('updated', u.modifiedCount); console.log('doc', await crud.getLocalById(id)); continue }
    if (op === '4') { const id = await askIntStrict('id: ', 1); const del = await crud.deleteLocalById(id); console.log('deleted', del.deletedCount); console.log('doc', await crud.getLocalById(id)); continue }
    console.log('Opción inválida')
  }
}

async function menuProductos(crud: BarberiaCRUD) {
  while (true) {
    console.log('\nProductos: 1) Crear 2) Leer 3) Actualizar 4) Eliminar 0) Atrás')
    const op = await ask('Opción: ')
    if (op === '0') break
    if (op === '1') { const id = await askIntStrict('id: ', 1); const stock = await askIntStrict('stock: ', 0); const nombre = await askNonEmpty('nombre: '); const tipo = await askNonEmpty('tipo: '); const estado = await askNonEmpty('estado: '); const r = await crud.createProducto({ id, nombre, tipo, estado, stock }); console.log('creado', r.insertedId); continue }
    if (op === '2') { const id = await askIntStrict('id: ', 1); console.log('doc', await crud.getProductoById(id)); continue }
    if (op === '3') { const id = await askIntStrict('id: ', 1); const nombre = await askOptionalString('nombre (enter): '); const tipo = await askOptionalString('tipo (enter): '); const estado = await askOptionalString('estado (enter): '); const stock = await askIntOptional('stock (enter para mantener, vacío=skip): '); const updates: Partial<any> = {}; if (nombre) updates.nombre = nombre; if (tipo) updates.tipo = tipo; if (estado) updates.estado = estado; if (stock !== undefined) updates.stock = stock; const u = await crud.updateProductoById(id, updates as any); console.log('updated', u.modifiedCount); console.log('doc', await crud.getProductoById(id)); continue }
    if (op === '4') { const id = await askIntStrict('id: ', 1); const del = await crud.deleteProductoById(id); console.log('deleted', del.deletedCount); console.log('doc', await crud.getProductoById(id)); continue }
    console.log('Opción inválida')
  }
}

async function menuServicios(crud: BarberiaCRUD) {
  while (true) {
    console.log('\nServicios: 1) Crear 2) Leer 3) Actualizar 4) Eliminar 0) Atrás')
    const op = await ask('Opción: ')
    if (op === '0') break
    if (op === '1') { const id = await askIntStrict('id: ', 1); const precio = await askIntStrict('precio: ', 0); const nombre = await askNonEmpty('nombre: '); const duracion = await askNonEmpty('duracion (N minutos): '); const r = await crud.createServicio({ id, nombre, precio, duracion }); console.log('creado', r.insertedId); continue }
    if (op === '2') { const id = await askIntStrict('id: ', 1); console.log('doc', await crud.getServicioById(id)); continue }
    if (op === '3') { const id = await askIntStrict('id: ', 1); const nombre = await askOptionalString('nombre (enter): '); const duracion = await askOptionalString('duracion (enter): '); const precio = await askIntOptional('precio (enter para mantener, vacío=skip): '); const updates: Partial<any> = {}; if (nombre) updates.nombre = nombre; if (duracion) updates.duracion = duracion; if (precio !== undefined) updates.precio = precio; const u = await crud.updateServicioById(id, updates as any); console.log('updated', u.modifiedCount); console.log('doc', await crud.getServicioById(id)); continue }
    if (op === '4') { const id = await askIntStrict('id: ', 1); const del = await crud.deleteServicioById(id); console.log('deleted', del.deletedCount); console.log('doc', await crud.getServicioById(id)); continue }
    console.log('Opción inválida')
  }
}

async function menuReservas(crud: BarberiaCRUD) {
  while (true) {
    console.log('\nReservas: 1) Crear 2) Leer 3) Actualizar 4) Eliminar 0) Atrás')
    const op = await ask('Opción: ')
    if (op === '0') break
    if (op === '1') {
      const id = await askIntStrict('id: ', 1)
      const fecha = await askDateISO('fecha (YYYY-MM-DD): ')
      const hora = await askTime('hora (HH:MM): ')
      const barberoId = await askIntStrict('barbero.id: ', 1); const barberoNombre = await askNonEmpty('barbero.nombre: ')
      const clienteId = await askIntStrict('cliente.id: ', 1); const clienteNombre = await askNonEmpty('cliente.nombre: ')
      const servicios: any[] = []
      while (true) {
        const add = (await ask('Agregar servicio? (s/n): ')).toLowerCase(); if (add !== 's') break
        const id_servicio = await askIntStrict('servicio.id_servicio: ', 1)
        const nombre = await askNonEmpty('servicio.nombre: ')
        const precio = await askIntStrict('servicio.precio: ', 0)
        const duracion = await askNonEmpty('servicio.duracion: ')
        servicios.push({ id_servicio, nombre, precio, duracion })
      }
      const r = await crud.createReserva({ id, fecha, hora, barbero: { id: barberoId, nombre: barberoNombre }, cliente: { id: clienteId, nombre: clienteNombre }, servicios })
      console.log('creado', r.insertedId); continue
    }
    if (op === '2') { const id = await askIntStrict('id: ', 1); console.log('doc', await crud.getReservaById(id)); continue }
    if (op === '3') {
      const id = await askIntStrict('id: ', 1)
      const hora = await askTimeOptional('hora (enter para mantener): ')
      const updates: Partial<any> = {}; if (hora !== undefined) updates.hora = hora
      const u = await crud.updateReservaById(id, updates as any)
      console.log('updated', u.modifiedCount)
      console.log('doc', await crud.getReservaById(id)); continue
    }
    if (op === '4') { const id = await askIntStrict('id: ', 1); const del = await crud.deleteReservaById(id); console.log('deleted', del.deletedCount); console.log('doc', await crud.getReservaById(id)); continue }
    console.log('Opción inválida')
  }
}

async function menuVentas(crud: BarberiaCRUD) {
  while (true) {
    console.log('\nVentas: 1) Crear 2) Leer 3) Actualizar 4) Eliminar 0) Atrás')
    const op = await ask('Opción: ')
    if (op === '0') break
    if (op === '1') {
      const id = await askIntStrict('id: ', 1)
      const fecha = await askDateISO('fecha (YYYY-MM-DD): ')
      const monto_total = await askIntStrict('monto_total: ', 0)
      const barberoId = await askIntStrict('barbero.id: ', 1); const barberoNombre = await askNonEmpty('barbero.nombre: ')
      const clienteId = await askIntStrict('cliente.id: ', 1); const clienteNombre = await askNonEmpty('cliente.nombre: ')
      const servicios: any[] = []
      while (true) { const add = (await ask('Agregar servicio? (s/n): ')).toLowerCase(); if (add !== 's') break
        const id_servicio = await askIntStrict('servicio.id_servicio: ', 1); const nombre = await askNonEmpty('servicio.nombre: ')
        const cantidad = await askIntStrict('servicio.cantidad: ', 1); const precio_unitario = await askIntStrict('servicio.precio_unitario: ', 0); const subtotal = await askIntStrict('servicio.subtotal: ', 0)
        servicios.push({ id_servicio, nombre, cantidad, precio_unitario, subtotal }) }
      const productos: any[] = []
      while (true) { const add = (await ask('Agregar producto? (s/n): ')).toLowerCase(); if (add !== 's') break
        const id_producto = await askIntStrict('producto.id_producto: ', 1); const nombre = await askNonEmpty('producto.nombre: ')
        const cantidad = await askIntStrict('producto.cantidad: ', 1); const subtotal = await askIntStrict('producto.subtotal: ', 0)
        productos.push({ id_producto, nombre, cantidad, subtotal }) }
      const r = await crud.createVenta({ id, fecha, monto_total, barbero: { id: barberoId, nombre: barberoNombre }, cliente: { id: clienteId, nombre: clienteNombre }, servicios, productos })
      console.log('creado', r.insertedId); continue }
    if (op === '2') { const id = await askIntStrict('id: ', 1); console.log('doc', await crud.getVentaById(id)); continue }
    if (op === '3') { const id = await askIntStrict('id: ', 1); const monto_total = await askIntOptional('monto_total (enter para mantener): '); const updates: Partial<any> = {}; if (monto_total !== undefined) updates.monto_total = monto_total; const u = await crud.updateVentaById(id, updates as any); console.log('updated', u.modifiedCount); console.log('doc', await crud.getVentaById(id)); continue }
    if (op === '4') { const id = await askIntStrict('id: ', 1); const del = await crud.deleteVentaById(id); console.log('deleted', del.deletedCount); console.log('doc', await crud.getVentaById(id)); continue }
    console.log('Opción inválida')
  }
}

async function main() {
  const crud = await BarberiaCRUD.fromEnv()
  while (true) {
    console.log('\nMenú Principal')
    console.log('1) Barberos')
    console.log('2) Clientes')
    console.log('3) Locales')
    console.log('4) Productos')
    console.log('5) Servicios')
    console.log('6) Reservas')
    console.log('7) Ventas')
    console.log('0) Salir')
    const op = await ask('Seleccione opción: ')
    if (op === '0') break
    if (op === '1') { await menuBarberos(crud); continue }
    if (op === '2') { await menuClientes(crud); continue }
    if (op === '3') { await menuLocales(crud); continue }
    if (op === '4') { await menuProductos(crud); continue }
    if (op === '5') { await menuServicios(crud); continue }
    if (op === '6') { await menuReservas(crud); continue }
    if (op === '7') { await menuVentas(crud); continue }
    console.log('Opción inválida')
  }
  process.exit(0)
}

main().catch(e => { console.error(e); process.exit(1) })
