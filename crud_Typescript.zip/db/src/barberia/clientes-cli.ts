import { BarberiaCRUD } from '../index'

/** CLI sencillo para ejecutar operaciones CRUD de Clientes */
async function main() {
  const args = process.argv.slice(2)
  const action = args[0] as 'create' | 'read' | 'update' | 'delete'
  const idArg = args.find(a => a.startsWith('--id='))?.split('=')[1]
  const id = idArg ? parseInt(idArg, 10) : undefined

  const crud = await BarberiaCRUD.fromEnv()

  if (action === 'create') {
    const useId = id ?? Math.floor(2000000 + (Date.now() % 1000000))
    await crud.createCliente({ id: useId, nombre: 'DemoCLI', telefono: '+56 9 1111 1111' })
    const doc = await crud.getClienteById(useId)
    console.log('CREATE OK id=' + useId, doc)
    return
  }

  if (!id) throw new Error('Missing --id for action ' + action)

  if (action === 'read') {
    const doc = await crud.getClienteById(id)
    console.log('READ', doc)
    return
  }

  if (action === 'update') {
    await crud.updateClienteById(id, { telefono: '+56 9 2222 2222' })
    const doc = await crud.getClienteById(id)
    console.log('UPDATE OK', doc)
    return
  }

  if (action === 'delete') {
    const res = await crud.deleteClienteById(id)
    console.log('DELETE OK', res)
    const doc = await crud.getClienteById(id)
    console.log('READ AFTER DELETE', doc)
    return
  }

  throw new Error('Unknown action, use: create | read | update | delete')
}

main().catch(e => { console.error(e); process.exit(1) })