import { promises as fs } from 'fs'
import { join } from 'path'
import { DatabaseConnection } from '../index'
import type { Barbero, Cliente, Local, Producto, Servicio, Reserva, Venta } from './modelos'
import { Int32 } from 'mongodb'

/** Lee y parsea un arreglo JSON desde archivo */
function parseJsonArray<T>(p: string) {
  return fs.readFile(p, 'utf-8').then(text => JSON.parse(text) as T[])
}

/** Convierte string ISO a Date si existe */
function toDate(s?: string) {
  return s ? new Date(s) : undefined
}

/** Remueve _id para evitar conflictos al importar */
function stripId<T extends Record<string, any>>(doc: T) {
  const { _id, ...rest } = doc
  return rest as T
}

/** Importa datos JSON de Barbería aplicando normalización */
async function main() {
  const baseDir = process.env.BARBERIA_DATA_DIR || 'c\\Users\\DUOC\\Documents\\trae_projects\\db\\Barberia'
  const conn = DatabaseConnection.fromEnv()
  const res = await conn.connect()
  if (!res.success) throw res.error
  const db = conn.getDatabase(process.env.MONGODB_DEFAULT_DB || 'admin')

  const barberos = (await parseJsonArray<Barbero>(join(baseDir, 'barberia.barberos.json'))).map(stripId)
    .map(b => ({ ...b, id: new Int32(b.id) as any, id_local: new Int32(b.id_local) as any }))
  const clientes = (await parseJsonArray<Cliente>(join(baseDir, 'barberia.clientes.json'))).map(stripId)
    .map(c => ({ ...c, id: new Int32(c.id) as any }))
  const locales = (await parseJsonArray<Local>(join(baseDir, 'barberia.locales.json'))).map(stripId)
    .map(l => ({ ...l, id: new Int32(l.id) as any }))
  const productos = (await parseJsonArray<Producto>(join(baseDir, 'barberia.productos.json'))).map(stripId)
    .map(p => ({ ...p, id: new Int32(p.id) as any, stock: new Int32(p.stock) as any }))
  const servicios = (await parseJsonArray<Servicio>(join(baseDir, 'barberia.servicios.json'))).map(stripId)
    .map(s => ({ ...s, id: new Int32(s.id) as any, precio: new Int32(s.precio) as any }))

  const reservasRaw = await parseJsonArray<any>(join(baseDir, 'barberia.reservas.json'))
  const reservas: Reserva[] = reservasRaw.map(r => {
    const rr = stripId(r)
    const servicios = Array.isArray(rr.servicios) ? rr.servicios.map((sv: any) => ({
      ...sv,
      id_servicio: new Int32(sv.id_servicio) as any,
      precio: new Int32(sv.precio) as any,
    })) : []
    const barbero = { ...rr.barbero, id: new Int32(rr.barbero?.id) as any }
    const cliente = { ...rr.cliente, id: new Int32(rr.cliente?.id) as any }
    return { ...rr, fecha: toDate(rr.fecha)!, id: new Int32(rr.id) as any, barbero, cliente, servicios }
  })

  const ventasRaw = await parseJsonArray<any>(join(baseDir, 'barberia.ventas.json'))
  const ventas: Venta[] = ventasRaw.map(v => {
    const vv = stripId(v)
    const servicios = Array.isArray(vv.servicios) ? vv.servicios.map((sv: any) => ({
      ...sv,
      id_servicio: new Int32(sv.id_servicio) as any,
      cantidad: new Int32(sv.cantidad) as any,
      precio_unitario: new Int32(sv.precio_unitario) as any,
      subtotal: new Int32(sv.subtotal) as any,
    })) : []
    const productos = Array.isArray(vv.productos) ? vv.productos.map((pr: any) => ({
      ...pr,
      id_producto: new Int32(pr.id_producto) as any,
      cantidad: new Int32(pr.cantidad) as any,
      subtotal: new Int32(pr.subtotal) as any,
    })) : []
    const barbero = { ...vv.barbero, id: new Int32(vv.barbero?.id) as any }
    const cliente = { ...vv.cliente, id: new Int32(vv.cliente?.id) as any }
    return { ...vv, fecha: toDate(vv.fecha)!, id: new Int32(vv.id) as any, monto_total: new Int32(vv.monto_total) as any, barbero, cliente, servicios, productos }
  })

  try {
    if (barberos.length) await db.collection<Barbero>('barberos').insertMany(barberos, { ordered: false })
  } catch (e: any) {
    const details = e?.errorResponse?.writeErrors?.[0]?.err || e
    console.error('Fallo barberos detalle', details)
    throw e
  }
  try { if (clientes.length) await db.collection<Cliente>('clientes').insertMany(clientes, { ordered: false }) } catch (e) { console.error('Fallo clientes', e as any); throw e }
  try { if (locales.length) await db.collection<Local>('locales').insertMany(locales, { ordered: false }) } catch (e) { console.error('Fallo locales', e as any); throw e }
  try { if (productos.length) await db.collection<Producto>('productos').insertMany(productos, { ordered: false }) } catch (e) { console.error('Fallo productos', e as any); throw e }
  try { if (servicios.length) await db.collection<Servicio>('servicios').insertMany(servicios, { ordered: false }) } catch (e) { console.error('Fallo servicios', e as any); throw e }
  try { if (reservas.length) await db.collection<Reserva>('reservas').insertMany(reservas, { ordered: false }) } catch (e) { console.error('Fallo reservas', e as any); throw e }
  try { if (ventas.length) await db.collection<Venta>('ventas').insertMany(ventas, { ordered: false }) } catch (e) { console.error('Fallo ventas', e as any); throw e }

  await conn.close()
}

main().catch(err => { console.error(err); process.exit(1) })