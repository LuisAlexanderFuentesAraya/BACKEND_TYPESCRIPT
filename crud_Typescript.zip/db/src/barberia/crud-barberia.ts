import { Int32, Collection, InsertOneResult, UpdateResult, DeleteResult, Document } from 'mongodb'
import { DatabaseConnection } from '../index'
import type { Barbero, Cliente, Local, Producto, Servicio, Reserva, Venta } from './modelos'

/** Convierte un número a Int32 cuando es necesario */
function i32(n: number | Int32 | undefined) { return n === undefined ? undefined : (n instanceof Int32 ? n : new Int32(n)) }

/** Normaliza enteros de Barbero para cumplir validadores */
function normBarbero(d: Barbero): Barbero { return { ...d, id: i32(d.id) as any, id_local: i32(d.id_local) as any } }
/** Normaliza parciales de Barbero sin introducir undefined en campos requeridos */
function normBarberoPartial(d: Partial<Barbero>): Partial<Barbero> {
  const ret: Partial<Barbero> = {}
  if (d.id !== undefined) ret.id = i32(d.id) as any
  if (d.id_local !== undefined) ret.id_local = i32(d.id_local) as any
  if (d.nombre !== undefined) ret.nombre = d.nombre
  if (d.horario !== undefined) ret.horario = d.horario
  return ret
}

/** Normaliza enteros de Cliente */
function normCliente(d: Cliente): Cliente { return { ...d, id: i32(d.id) as any } }
/** Normaliza parciales de Cliente */
function normClientePartial(d: Partial<Cliente>): Partial<Cliente> {
  const ret: Partial<Cliente> = {}
  if (d.id !== undefined) ret.id = i32(d.id) as any
  if (d.nombre !== undefined) ret.nombre = d.nombre
  if (d.telefono !== undefined) ret.telefono = d.telefono
  return ret
}

/** Normaliza enteros de Local */
function normLocal(d: Local): Local { return { ...d, id: i32(d.id) as any } }
/** Normaliza parciales de Local */
function normLocalPartial(d: Partial<Local>): Partial<Local> {
  const ret: Partial<Local> = {}
  if (d.id !== undefined) ret.id = i32(d.id) as any
  if (d.nombre !== undefined) ret.nombre = d.nombre
  if (d.direccion !== undefined) ret.direccion = d.direccion
  return ret
}

/** Normaliza enteros de Producto */
function normProducto(d: Producto): Producto { return { ...d, id: i32(d.id) as any, stock: i32(d.stock) as any } }
/** Normaliza parciales de Producto */
function normProductoPartial(d: Partial<Producto>): Partial<Producto> {
  const ret: Partial<Producto> = {}
  if (d.id !== undefined) ret.id = i32(d.id) as any
  if (d.nombre !== undefined) ret.nombre = d.nombre
  if (d.tipo !== undefined) ret.tipo = d.tipo
  if (d.estado !== undefined) ret.estado = d.estado
  if (d.stock !== undefined) ret.stock = i32(d.stock) as any
  return ret
}

/** Normaliza enteros de Servicio */
function normServicio(d: Servicio): Servicio { return { ...d, id: i32(d.id) as any, precio: i32(d.precio) as any } }
/** Normaliza parciales de Servicio */
function normServicioPartial(d: Partial<Servicio>): Partial<Servicio> {
  const ret: Partial<Servicio> = {}
  if (d.id !== undefined) ret.id = i32(d.id) as any
  if (d.nombre !== undefined) ret.nombre = d.nombre
  if (d.precio !== undefined) ret.precio = i32(d.precio) as any
  if (d.duracion !== undefined) ret.duracion = d.duracion
  return ret
}

/** Normaliza enteros y estructuras de Reserva */
function normReserva(d: Reserva): Reserva {
  const servicios = (d.servicios ?? []).map((s: Reserva['servicios'][number]) => ({ ...s, id_servicio: i32(s.id_servicio) as any, precio: i32(s.precio) as any }))
  const barbero = { ...d.barbero, id: i32(d.barbero?.id) as any }
  const cliente = { ...d.cliente, id: i32(d.cliente?.id) as any }
  return { ...d, id: i32(d.id) as any, servicios, barbero, cliente }
}
/** Normaliza parciales de Reserva incluyendo sub-docs */
function normReservaPartial(d: Partial<Reserva>): Partial<Reserva> {
  const servicios = Array.isArray(d.servicios) ? d.servicios.map((s: Reserva['servicios'][number]) => ({ ...s, id_servicio: i32(s.id_servicio) as any, precio: i32(s.precio) as any })) : d.servicios
  const barbero = d.barbero ? { ...d.barbero, id: i32(d.barbero?.id) as any } : undefined
  const cliente = d.cliente ? { ...d.cliente, id: i32(d.cliente?.id) as any } : undefined
  const ret: Partial<Reserva> = { ...d, id: i32(d.id) as any }
  if (servicios !== undefined) ret.servicios = servicios
  if (barbero !== undefined) ret.barbero = barbero
  if (cliente !== undefined) ret.cliente = cliente
  return ret
}

/** Normaliza enteros y estructuras de Venta */
function normVenta(d: Venta): Venta {
  const servicios = (d.servicios ?? []).map((s: Venta['servicios'][number]) => ({ ...s, id_servicio: i32(s.id_servicio) as any, cantidad: i32(s.cantidad) as any, precio_unitario: i32(s.precio_unitario) as any, subtotal: i32(s.subtotal) as any }))
  const productos = (d.productos ?? []).map((p: Venta['productos'][number]) => ({ ...p, id_producto: i32(p.id_producto) as any, cantidad: i32(p.cantidad) as any, subtotal: i32(p.subtotal) as any }))
  const barbero = { ...d.barbero, id: i32(d.barbero?.id) as any }
  const cliente = { ...d.cliente, id: i32(d.cliente?.id) as any }
  return { ...d, id: i32(d.id) as any, monto_total: i32(d.monto_total) as any, servicios, productos, barbero, cliente }
}
/** Normaliza parciales de Venta incluyendo sub-docs */
function normVentaPartial(d: Partial<Venta>): Partial<Venta> {
  const servicios = Array.isArray(d.servicios) ? d.servicios.map((s: Venta['servicios'][number]) => ({ ...s, id_servicio: i32(s.id_servicio) as any, cantidad: i32(s.cantidad) as any, precio_unitario: i32(s.precio_unitario) as any, subtotal: i32(s.subtotal) as any })) : d.servicios
  const productos = Array.isArray(d.productos) ? d.productos.map((p: Venta['productos'][number]) => ({ ...p, id_producto: i32(p.id_producto) as any, cantidad: i32(p.cantidad) as any, subtotal: i32(p.subtotal) as any })) : d.productos
  const barbero = d.barbero ? { ...d.barbero, id: i32(d.barbero?.id) as any } : undefined
  const cliente = d.cliente ? { ...d.cliente, id: i32(d.cliente?.id) as any } : undefined
  const ret: Partial<Venta> = { ...d, id: i32(d.id) as any }
  if (d.monto_total !== undefined) ret.monto_total = i32(d.monto_total) as any
  if (servicios !== undefined) ret.servicios = servicios
  if (productos !== undefined) ret.productos = productos
  if (barbero !== undefined) ret.barbero = barbero
  if (cliente !== undefined) ret.cliente = cliente
  return ret
}

/**
 * CRUD tipado para colecciones de Barbería.
 * Usa `DatabaseConnection` y normalización para validadores JSON Schema.
 */
export class BarberiaCRUD {
  constructor(private readonly conn: DatabaseConnection, private readonly dbName?: string) {}
  /** Crea instancia conectada usando variables de entorno */
  static async fromEnv() { const c = DatabaseConnection.fromEnv(); const r = await c.connect(); if (!r.success) throw r.error; return new BarberiaCRUD(c) }
  /** Obtiene colección tipada */
  private col<T extends Document>(name: string): Collection<T> { const db = this.conn.getDatabase(this.dbName ?? process.env.MONGODB_DEFAULT_DB ?? 'admin'); return db.collection<T>(name) }

  async createBarbero(doc: Barbero): Promise<InsertOneResult<Barbero>> { return this.col<Barbero>('barberos').insertOne(normBarbero(doc)) }
  async getBarberoById(id: number): Promise<Barbero | null> { return this.col<Barbero>('barberos').findOne({ id: i32(id) as any }) }
  async listBarberos(filter?: Partial<Barbero>): Promise<Barbero[]> { return this.col<Barbero>('barberos').find(normBarberoPartial(filter ?? {})).toArray() }
  async updateBarberoById(id: number, updates: Partial<Barbero>): Promise<UpdateResult> { return this.col<Barbero>('barberos').updateOne({ id: i32(id) as any }, { $set: normBarberoPartial(updates) }) }
  async deleteBarberoById(id: number): Promise<DeleteResult> { return this.col<Barbero>('barberos').deleteOne({ id: i32(id) as any }) }

  async createCliente(doc: Cliente): Promise<InsertOneResult<Cliente>> { return this.col<Cliente>('clientes').insertOne(normCliente(doc)) }
  async getClienteById(id: number): Promise<Cliente | null> { return this.col<Cliente>('clientes').findOne({ id: i32(id) as any }) }
  async listClientes(filter?: Partial<Cliente>): Promise<Cliente[]> { return this.col<Cliente>('clientes').find(normClientePartial(filter ?? {})).toArray() }
  async updateClienteById(id: number, updates: Partial<Cliente>): Promise<UpdateResult> { return this.col<Cliente>('clientes').updateOne({ id: i32(id) as any }, { $set: normClientePartial(updates) }) }
  async deleteClienteById(id: number): Promise<DeleteResult> { return this.col<Cliente>('clientes').deleteOne({ id: i32(id) as any }) }

  async createLocal(doc: Local): Promise<InsertOneResult<Local>> { return this.col<Local>('locales').insertOne(normLocal(doc)) }
  async getLocalById(id: number): Promise<Local | null> { return this.col<Local>('locales').findOne({ id: i32(id) as any }) }
  async listLocales(filter?: Partial<Local>): Promise<Local[]> { return this.col<Local>('locales').find(normLocalPartial(filter ?? {})).toArray() }
  async updateLocalById(id: number, updates: Partial<Local>): Promise<UpdateResult> { return this.col<Local>('locales').updateOne({ id: i32(id) as any }, { $set: normLocalPartial(updates) }) }
  async deleteLocalById(id: number): Promise<DeleteResult> { return this.col<Local>('locales').deleteOne({ id: i32(id) as any }) }

  async createProducto(doc: Producto): Promise<InsertOneResult<Producto>> { return this.col<Producto>('productos').insertOne(normProducto(doc)) }
  async getProductoById(id: number): Promise<Producto | null> { return this.col<Producto>('productos').findOne({ id: i32(id) as any }) }
  async listProductos(filter?: Partial<Producto>): Promise<Producto[]> { return this.col<Producto>('productos').find(normProductoPartial(filter ?? {})).toArray() }
  async updateProductoById(id: number, updates: Partial<Producto>): Promise<UpdateResult> { return this.col<Producto>('productos').updateOne({ id: i32(id) as any }, { $set: normProductoPartial(updates) }) }
  async deleteProductoById(id: number): Promise<DeleteResult> { return this.col<Producto>('productos').deleteOne({ id: i32(id) as any }) }

  async createServicio(doc: Servicio): Promise<InsertOneResult<Servicio>> { return this.col<Servicio>('servicios').insertOne(normServicio(doc)) }
  async getServicioById(id: number): Promise<Servicio | null> { return this.col<Servicio>('servicios').findOne({ id: i32(id) as any }) }
  async listServicios(filter?: Partial<Servicio>): Promise<Servicio[]> { return this.col<Servicio>('servicios').find(normServicioPartial(filter ?? {})).toArray() }
  async updateServicioById(id: number, updates: Partial<Servicio>): Promise<UpdateResult> { return this.col<Servicio>('servicios').updateOne({ id: i32(id) as any }, { $set: normServicioPartial(updates) }) }
  async deleteServicioById(id: number): Promise<DeleteResult> { return this.col<Servicio>('servicios').deleteOne({ id: i32(id) as any }) }

  async createReserva(doc: Reserva): Promise<InsertOneResult<Reserva>> { return this.col<Reserva>('reservas').insertOne(normReserva(doc)) }
  async getReservaById(id: number): Promise<Reserva | null> { return this.col<Reserva>('reservas').findOne({ id: i32(id) as any }) }
  async listReservas(filter?: Partial<Reserva>): Promise<Reserva[]> { return this.col<Reserva>('reservas').find(normReservaPartial(filter ?? {})).toArray() }
  async updateReservaById(id: number, updates: Partial<Reserva>): Promise<UpdateResult> { return this.col<Reserva>('reservas').updateOne({ id: i32(id) as any }, { $set: normReservaPartial(updates) }) }
  async deleteReservaById(id: number): Promise<DeleteResult> { return this.col<Reserva>('reservas').deleteOne({ id: i32(id) as any }) }

  async createVenta(doc: Venta): Promise<InsertOneResult<Venta>> { return this.col<Venta>('ventas').insertOne(normVenta(doc)) }
  async getVentaById(id: number): Promise<Venta | null> { return this.col<Venta>('ventas').findOne({ id: i32(id) as any }) }
  async listVentas(filter?: Partial<Venta>): Promise<Venta[]> { return this.col<Venta>('ventas').find(normVentaPartial(filter ?? {})).toArray() }
  async updateVentaById(id: number, updates: Partial<Venta>): Promise<UpdateResult> { return this.col<Venta>('ventas').updateOne({ id: i32(id) as any }, { $set: normVentaPartial(updates) }) }
  async deleteVentaById(id: number): Promise<DeleteResult> { return this.col<Venta>('ventas').deleteOne({ id: i32(id) as any }) }
}
