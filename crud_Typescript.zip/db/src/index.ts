export {
  DatabaseConnection,
  ConnectionError,
  PingError,
  CloseError,
} from './db/conexion'

export type {
  ConnectionMode,
  OperationResult,
  MongoErrorLike,
  ConnectionOptions,
  ApiConfigParams,
  MongoConfigParams,
  MongoClientOptions,
  ServerApiVersion,
  Db,
  Collection,
  InsertOneResult,
  UpdateResult,
  DeleteResult,
} from './db/conexion'

export { BarberiaCRUD } from './barberia/crud-barberia'
export type { Barbero, Cliente, Local, Producto, Servicio, Reserva, Venta } from './barberia/modelos'