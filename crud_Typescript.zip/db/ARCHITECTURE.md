# Arquitectura del Proyecto

## Visión General
- Proyecto Node.js/TypeScript para gestionar una base MongoDB de Barbería.
- Incluye:
  - Módulo de conexión tipado a MongoDB
  - CRUD para todas las colecciones de dominio
  - Aplicación de validadores (JSON Schema) e índices
  - Importación de datos desde archivos JSON
  - Clientes de consola (menú interactivo y CLI)

## Capas y Responsabilidades
- `src/db/conexion.ts`
  - Encapsula `MongoClient`, lectura de variables de entorno y opciones.
  - Métodos principales: `connect` (`src/db/conexion.ts:41`), `ping` (`src/db/conexion.ts:58`), `close` (`src/db/conexion.ts:68`), `getDatabase` (`src/db/conexion.ts:73`), `fromEnv` (`src/db/conexion.ts:79`).

- `src/barberia/modelos.ts`
  - Modelos de dominio (`Barbero`, `Cliente`, `Local`, `Producto`, `Servicio`, `Reserva`, `Venta`).

- `src/barberia/crud-barberia.ts`
  - CRUD tipado por colección con normalización de enteros (`Int32`) y subdocumentos.
  - Helper `i32` para convertir a `Int32` (`src/barberia/crud-barberia.ts:6`).
  - Normalización de `Reserva` (`src/barberia/crud-barberia.ts:68`), `Venta` (`src/barberia/crud-barberia.ts:87`).
  - Clase `BarberiaCRUD` (`src/barberia/crud-barberia.ts:113`), fábrica `fromEnv` (`src/barberia/crud-barberia.ts:115`), acceso a colección `col` (`src/barberia/crud-barberia.ts:117`).

- `src/barberia/configurar-esquemas.ts`
  - Define validadores JSON Schema por colección y aplica índices.
  - Aplicación de validadores con `applyValidator` (`src/barberia/configurar-esquemas.ts:83`).
  - Índices únicos por `id` y auxiliares por campos anidados (`src/barberia/configurar-esquemas.ts:106`).

- `src/barberia/importar-datos.ts`
  - Importa datos desde JSON y normaliza tipos para cumplir validadores.
  - Conversión a `Int32` y `Date` en colecciones y subdocumentos (`src/barberia/importar-datos.ts:31`, `src/barberia/importar-datos.ts:42`, `src/barberia/importar-datos.ts:55`).

- `src/barberia/menu-consola.ts`
  - Menú interactivo para CRUD de todas las colecciones con validaciones de entrada.
  - Navegación por módulos y operaciones en bucles controlados (`src/barberia/menu-consola.ts:167`).

- `src/barberia/clientes-cli.ts`
  - CLI orientado a `Clientes` para ejecutar acciones puntuales vía argumentos (`src/barberia/clientes-cli.ts:3`).

- `src/index.ts`
  - Punto de entrada y exportaciones para reutilizar el módulo.

## Flujo típico
1. Configurar `.env` o variables de entorno (URI y DB).
2. Ejecutar `npm run schema` para crear validadores e índices.
3. Opcional: `npm run seed` para importar datos base.
4. Usar `npm run menu` para gestionar datos por consola o `npm run cli` para operaciones puntuales.

## Decisiones de Diseño
- Se usa `Int32` para cumplir validadores `bsonType: "int"` y evitar errores de validación.
- `id` es clave de negocio única por colección; `_id` lo maneja Mongo.
- Validadores estrictos para mantener integridad de datos.

## Estándares de Código
- TypeScript en modo `strict` con `exactOptionalPropertyTypes`.
- Normalización defensiva en actualizaciones: nunca se escriben `undefined` en campos requeridos.
- Scripts de verificación: `typecheck` y `build`.

## Funcionamiento
- Conexión a MongoDB: `DatabaseConnection.fromEnv()` carga variables y configura `MongoClient` (`src/db/conexion.ts:79`). `connect()` establece la conexión con `ServerApiVersion.v1` y opciones estrictas (`src/db/conexion.ts:41`).
- Validación por JSON Schema: los validadores se aplican por colección y bloquean documentos inválidos con `validationAction: "error"` (`src/barberia/configurar-esquemas.ts:86`, `src/barberia/configurar-esquemas.ts:88`).
- Normalización de tipos: antes de escribir, los enteros se convierten a `Int32` y se ajustan subdocumentos anidados para que coincidan con el esquema (`src/barberia/crud-barberia.ts:68`, `src/barberia/crud-barberia.ts:87`).
- Importación de datos: los JSON se transforman para remover `_id`, convertir fechas ISO a `Date` y números a `Int32` (`src/barberia/importar-datos.ts:17`, `src/barberia/importar-datos.ts:31`, `src/barberia/importar-datos.ts:55`).
- Índices y consultas: índices únicos por `id` garantizan unicidad; índices por `barbero.id`, `cliente.id` y `fecha` aceleran consultas frecuentes (`src/barberia/configurar-esquemas.ts:114`).